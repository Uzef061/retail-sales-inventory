const Product = require('../models/Product');
const Customer = require('../models/Customer');
const Sale = require('../models/Sale');
const User = require('../models/User');

const seedData = async () => {
  try {
    // Clear existing data when explicit re-seed is triggered
    await Product.deleteMany({});
    await Customer.deleteMany({});
    await Sale.deleteMany({});
    await User.deleteMany({});

    console.log('Cleared existing database entries.');

    // 1. Create Admin & Cashier Users
    await User.create([
      { username: 'admin', password: 'password123', name: 'Store Admin', role: 'ADMIN' },
      { username: 'cashier', password: 'password123', name: 'Billing Cashier', role: 'CASHIER' }
    ]);
    console.log('Created admin (admin / password123) and cashier (cashier / password123) users.');

    // 2. Create 10 Products with realistic Cost Price & Selling Price
    const sampleProducts = [
      { name: 'Organic Coffee Beans 500g', category: 'Beverages', costPrice: 300, sellingPrice: 450, price: 450, stock: 25 },
      { name: 'Green Tea Bags Box (50s)', category: 'Beverages', costPrice: 180, sellingPrice: 280, price: 280, stock: 15 },
      { name: 'Dark Chocolate Bar 70%', category: 'Snacks', costPrice: 90, sellingPrice: 150, price: 150, stock: 40 },
      { name: 'Oat Milk 1 Litre', category: 'Dairy Alternatives', costPrice: 150, sellingPrice: 220, price: 220, stock: 8 }, // Low Stock
      { name: 'Stainless Steel Water Bottle 750ml', category: 'Accessories', costPrice: 420, sellingPrice: 650, price: 650, stock: 12 },
      { name: 'Ceramic Coffee Mug 350ml', category: 'Accessories', costPrice: 180, sellingPrice: 300, price: 300, stock: 5 }, // Low Stock
      { name: 'Eco Canvas Tote Bag', category: 'Accessories', costPrice: 140, sellingPrice: 250, price: 250, stock: 30 },
      { name: 'Raw Artisanal Honey 500g', category: 'Pantry', costPrice: 380, sellingPrice: 550, price: 550, stock: 4 }, // Low Stock
      { name: 'Extra Virgin Olive Oil 500ml', category: 'Pantry', costPrice: 520, sellingPrice: 780, price: 780, stock: 18 },
      { name: 'Almond Crunch Granola 400g', category: 'Snacks', costPrice: 260, sellingPrice: 380, price: 380, stock: 0 }  // Out of Stock
    ];

    const insertedProducts = await Product.insertMany(sampleProducts);
    console.log(`Inserted ${insertedProducts.length} products with cost & selling prices.`);

    // 3. Create 5 Customers
    const sampleCustomers = [
      { name: 'Rahul Sharma', phone: '+91 9876543210', email: 'rahul.sharma@example.com' },
      { name: 'Priya Patel', phone: '+91 9812345678', email: 'priya.patel@example.com' },
      { name: 'Ananya Sen', phone: '+91 9765432109', email: 'ananya.sen@example.com' },
      { name: 'Vikram Malhotra', phone: '+91 9654321098', email: 'vikram.m@example.com' },
      { name: 'Sneha Gupta', phone: '+91 9543210987', email: 'sneha.gupta@example.com' }
    ];

    const insertedCustomers = await Customer.insertMany(sampleCustomers);
    console.log(`Inserted ${insertedCustomers.length} customers.`);

    // 4. Create Sales distributed across periods
    const now = new Date();
    const daysAgo = (days) => {
      const d = new Date(now);
      d.setDate(d.getDate() - days);
      return d;
    };

    const makeSaleData = (custIdx, prodIdx, qty, daysBack) => {
      const p = insertedProducts[prodIdx];
      const sp = p.sellingPrice;
      const cp = p.costPrice;
      const totalAmount = sp * qty;
      const totalCostAmount = cp * qty;
      const profit = totalAmount - totalCostAmount;
      return {
        customer: insertedCustomers[custIdx]._id,
        product: p._id,
        quantity: qty,
        sellingPrice: sp,
        costPrice: cp,
        totalAmount,
        totalCostAmount,
        profit,
        saleDate: daysAgo(daysBack)
      };
    };

    const sampleSales = [
      // Current Week / Last 7 Days (0 to 3 days ago)
      makeSaleData(0, 0, 2, 0), // Today: Coffee x2 (Rev: 900, Cost: 600, Profit: 300)
      makeSaleData(1, 4, 1, 1), // 1 day ago: Bottle x1 (Rev: 650, Cost: 420, Profit: 230)
      makeSaleData(2, 2, 4, 2), // 2 days ago: Choco x4 (Rev: 600, Cost: 360, Profit: 240)
      makeSaleData(3, 8, 1, 3), // 3 days ago: Olive Oil x1 (Rev: 780, Cost: 520, Profit: 260)

      // Immediately Preceding Calendar Week / Previous Week (8 to 11 days ago)
      makeSaleData(4, 1, 3, 8),  // 8 days ago: Green Tea x3 (Rev: 840, Cost: 540, Profit: 300)
      makeSaleData(0, 6, 2, 9),  // 9 days ago: Tote Bag x2 (Rev: 500, Cost: 280, Profit: 220)
      makeSaleData(1, 3, 2, 10), // 10 days ago: Oat Milk x2 (Rev: 440, Cost: 300, Profit: 140)
      makeSaleData(2, 0, 2, 11), // 11 days ago: Coffee x2 (Rev: 900, Cost: 600, Profit: 300)

      // Rolling 30-Day Window (16 to 24 days ago)
      makeSaleData(3, 5, 2, 16), // 16 days ago: Mug x2 (Rev: 600, Cost: 360, Profit: 240)
      makeSaleData(4, 2, 5, 20), // 20 days ago: Choco x5 (Rev: 750, Cost: 450, Profit: 300)
      makeSaleData(0, 4, 1, 24), // 24 days ago: Bottle x1 (Rev: 650, Cost: 420, Profit: 230)

      // Rolling 90-Day / All Time Window (35 to 55 days ago)
      makeSaleData(1, 8, 2, 35), // 35 days ago: Olive Oil x2 (Rev: 1560, Cost: 1040, Profit: 520)
      makeSaleData(2, 1, 4, 45), // 45 days ago: Green Tea x4 (Rev: 1120, Cost: 720, Profit: 400)
      makeSaleData(3, 6, 4, 55)  // 55 days ago: Tote Bag x4 (Rev: 1000, Cost: 560, Profit: 440)
    ];

    const insertedSales = await Sale.insertMany(sampleSales);
    console.log(`Inserted ${insertedSales.length} sample sales with profit snapshot data.`);

    return {
      message: 'Database seeded successfully',
      productsCount: insertedProducts.length,
      customersCount: insertedCustomers.length,
      salesCount: insertedSales.length
    };
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
};

/**
 * Safely ensure historical demo sales exist for all periods without deleting or wiping current data.
 */
const ensureHistoricalSales = async () => {
  try {
    const products = await Product.find();
    const customers = await Customer.find();

    if (products.length === 0 || customers.length === 0) {
      console.log('Database missing products or customers. Seeding dataset...');
      return await seedData();
    }

    const { buildPeriodMatch } = require('../utils/periodUtils');
    const now = new Date();
    const daysAgo = (days) => {
      const d = new Date(now);
      d.setDate(d.getDate() - days);
      return d;
    };

    const periodsToCheck = [
      { period: 'thisWeek', daysBack: [0, 1, 2] },
      { period: 'prevWeek', daysBack: [8, 9, 10] },
      { period: '30days', daysBack: [16, 20, 24] },
      { period: '90days', daysBack: [35, 45, 55] }
    ];

    const missingSales = [];

    for (const pItem of periodsToCheck) {
      const match = buildPeriodMatch(pItem.period);
      const existingCount = await Sale.countDocuments(match);

      if (existingCount === 0) {
        pItem.daysBack.forEach((days, idx) => {
          const prod = products[idx % products.length];
          const cust = customers[idx % customers.length];
          const qty = (idx % 3) + 1;
          const sp = prod.sellingPrice || prod.price || 300;
          const cp = prod.costPrice || Math.round(sp * 0.7);
          const totalAmount = sp * qty;
          const totalCostAmount = cp * qty;
          const profit = totalAmount - totalCostAmount;

          missingSales.push({
            customer: cust._id,
            product: prod._id,
            quantity: qty,
            sellingPrice: sp,
            costPrice: cp,
            totalAmount,
            totalCostAmount,
            profit,
            saleDate: daysAgo(days)
          });
        });
      }
    }

    if (missingSales.length > 0) {
      await Sale.insertMany(missingSales);
      console.log(`Inserted ${missingSales.length} missing historical sales records without wiping existing data.`);
    } else {
      console.log('Historical sales records present for all periods.');
    }
  } catch (err) {
    console.error('Error ensuring historical sales:', err.message);
  }
};

const ensureDemoUsers = async () => {
  try {
    let admin = await User.findOne({ username: 'admin' });
    if (!admin) {
      await User.create({ username: 'admin', password: 'password123', name: 'Store Admin', role: 'ADMIN' });
      console.log('Ensured admin user exists (admin / password123).');
    }
    let cashier = await User.findOne({ username: 'cashier' });
    if (!cashier) {
      await User.create({ username: 'cashier', password: 'password123', name: 'Billing Cashier', role: 'CASHIER' });
      console.log('Ensured cashier user exists (cashier / password123).');
    }
  } catch (err) {
    console.error('Error ensuring demo users:', err.message);
  }
};

module.exports = seedData;
module.exports.ensureHistoricalSales = ensureHistoricalSales;
module.exports.ensureDemoUsers = ensureDemoUsers;
